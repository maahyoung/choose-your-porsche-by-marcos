/* eslint-disable @next/next/no-img-element */
"use client";

import { useState } from "react";
import { copy } from "@/config/translations";
import { Quality, useConfigurator } from "@/store/configurator";

const qualityOrder: Quality[] = ["performance", "balanced", "ultra"];

const qualityLabels = {
  en: {
    performance: "Performance",
    balanced: "Balanced",
    ultra: "Ultra",
  },
  pt: {
    performance: "Desempenho",
    balanced: "Equilibrado",
    ultra: "Ultra",
  },
} as const;

function SlidersIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="top-action-svg">
      <path d="M4 7h5m4 0h7M4 17h9m4 0h3" />
      <circle cx="11" cy="7" r="2" />
      <circle cx="15" cy="17" r="2" />
    </svg>
  );
}

function ShareIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true" className="top-action-svg">
      <path d="M12 3v11m0-11L8.5 6.5M12 3l3.5 3.5" />
      <path d="M6 10.5H4.8A1.8 1.8 0 0 0 3 12.3v6.9A1.8 1.8 0 0 0 4.8 21h14.4a1.8 1.8 0 0 0 1.8-1.8v-6.9a1.8 1.8 0 0 0-1.8-1.8H18" />
    </svg>
  );
}

export function TopBar() {
  const language = useConfigurator((state) => state.language);
  const setLanguage = useConfigurator((state) => state.setLanguage);
  const quality = useConfigurator((state) => state.quality);
  const paintId = useConfigurator((state) => state.paintId);
  const wheelId = useConfigurator((state) => state.wheelId);
  const caliperId = useConfigurator((state) => state.caliperId);
  const roofFinishId = useConfigurator((state) => state.roofFinishId);
  const mirrorFinishId = useConfigurator((state) => state.mirrorFinishId);
  const exhaustFinishId = useConfigurator((state) => state.exhaustFinishId);
  const environmentId = useConfigurator((state) => state.environmentId);
  const cameraPresetId = useConfigurator((state) => state.cameraPresetId);
  const hoodOpen = useConfigurator((state) => state.hoodOpen);
  const leftDoorOpen = useConfigurator((state) => state.leftDoorOpen);
  const rightDoorOpen = useConfigurator((state) => state.rightDoorOpen);
  const wingInstalled = useConfigurator((state) => state.wingInstalled);
  const headlights = useConfigurator((state) => state.headlights);
  const taillights = useConfigurator((state) => state.taillights);
  const setQuality = useConfigurator((state) => state.setQuality);

  const [copied, setCopied] = useState(false);
  const t = copy[language];

  const nextQuality = () => {
    const currentIndex = qualityOrder.indexOf(quality);
    const nextIndex = (currentIndex + 1) % qualityOrder.length;
    setQuality(qualityOrder[nextIndex]);
  };

  const shareBuild = async () => {
    const buildUrl = new URL(window.location.href);
    buildUrl.searchParams.set("paint", paintId);
    buildUrl.searchParams.set("wheel", wheelId);
    buildUrl.searchParams.set("caliper", caliperId);
    buildUrl.searchParams.set("roof", roofFinishId);
    buildUrl.searchParams.set("mirrors", mirrorFinishId);
    buildUrl.searchParams.set("exhaust", exhaustFinishId);
    buildUrl.searchParams.set("environment", environmentId);
    buildUrl.searchParams.set("camera", cameraPresetId);
    buildUrl.searchParams.set("hood", hoodOpen ? "1" : "0");
    buildUrl.searchParams.set("doorL", leftDoorOpen ? "1" : "0");
    buildUrl.searchParams.set("doorR", rightDoorOpen ? "1" : "0");
    buildUrl.searchParams.set("wing", wingInstalled ? "1" : "0");
    buildUrl.searchParams.set("lights", headlights ? "1" : "0");
    buildUrl.searchParams.set("tails", taillights ? "1" : "0");
    const url = buildUrl.toString();

    try {
      if (navigator.share) {
        await navigator.share({ title: "911 by Marcos", url });
        return;
      }

      await navigator.clipboard.writeText(url);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1800);
    } catch {
      setCopied(false);
    }
  };

  return (
    <>
      <header className="top-bar">
        <div className="hero-left-lockup">
          <img
            src="/brand/porsche-crest.svg"
            alt="Porsche crest"
            className="porsche-crest"
          />

          <div className="identity-copy">
            <div className="nine-eleven-lockup">
              <span className="nine-eleven">911</span>
              <span className="by-marcos-script">by Marcos</span>
            </div>
          </div>
        </div>

        <div className="center-wordmark" aria-label="Porsche">
          <img
            src="/brand/porsche-wordmark.svg"
            alt="Porsche"
            className="porsche-wordmark-image"
          />
        </div>

        <div className="top-actions" aria-label="Experience controls">
          <button
            className="top-action-button language-action"
            onClick={() => setLanguage(language === "pt" ? "en" : "pt")}
            aria-label="Change language"
            title="Change language"
          >
            {language.toUpperCase()}
          </button>

          <button
            className="top-action-button quality-action"
            onClick={nextQuality}
            aria-label={`${t.quality}: ${qualityLabels[language][quality]}`}
            title={`${t.quality}: ${qualityLabels[language][quality]}`}
          >
            <SlidersIcon />
            <span>{qualityLabels[language][quality]}</span>
          </button>

          <button
            className="top-action-button icon-action"
            onClick={shareBuild}
            aria-label={t.share}
            title={t.share}
          >
            <ShareIcon />
          </button>
        </div>
      </header>

      {copied && <div className="toast">{t.copied}</div>}
    </>
  );
}
